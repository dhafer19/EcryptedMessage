This folder contains two clients and one server. To set this up you must first start each of them in the correct order.
First the server, then Alice, then Bob. The order will be determined by the order their pre shared keys are entered.
The pre-shared key can be anything but must match on both sides to properly encrypt and decrypt.


Alice can then send a message to bob. This is encrypted using a vigenere cipher then sent to the server. The server then
will receive it encrypted and forward it to Bob. Bob will receive it and then decrypt it using the same cipher and shared key.
