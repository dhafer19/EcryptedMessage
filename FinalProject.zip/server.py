#server.py
#Dan Hafer, Savannah Sannabria, Riley Macdonald

import socket


HOST = 'localhost'
PORT = 11111
ACK_TEXT = 'Text Received'
BUFFER_SIZE = 1024


def main():
    # instantiate a socket object
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print('socket instantiated')

    # bind the socket
    sock.bind((HOST, PORT))
    print('socket binded')

    # start the socket listening for two connections. The two clients Bob and Alice
    sock.listen(2)
    print('socket now listening')

    # accept the socket response from the clients, and get the connection objects

    conn, addr = sock.accept()
    conn2, addr2 = sock.accept()

    # Note: execution# on waits here until the client calls sock.connect()
    print('socket accepted, connection object')

    # Continued Loop For testing of the connection.
    Running = True
    while Running:
            messageAtoB = receiveTextViaSocket(conn)
            print('Recieved: ' + messageAtoB)
            forwardtoB(messageAtoB, conn2)


def forwardtoB(message, conn):
    print("Forwarding on to B")
    sendTextViaSocket(message, conn)


def sendTextViaSocket(message, sock):
    """
    This method allows you to send a message over a socket connection
    :param message: messsage string
    :param sock: the socket to send it over. type=Socket
    """
    # encode the text message
    encodedMessage = bytes(message, 'utf-8')

    # send the data via the socket to the server
    sock.sendall(encodedMessage)
    #sock.sendall(message)

    # receive acknowledgment from the server
    encodedAckText = sock.recv(BUFFER_SIZE) # size
    ackText = encodedAckText.decode('utf-8')

    # log if acknowledgment was successful
    if ackText == ACK_TEXT:
        print('server acknowledged reception of text')
    else:
        print('error: server has sent back ' + ackText)


def receiveTextViaSocket(sock):
    """
    Method that will recieve a message via the socket
    :param sock: Put the connection that you want to send the message along
    :return: recieved message
    """
    # get the text via the socket
    encodedMessage = sock.recv(BUFFER_SIZE)

    # if we didn't get anything, log an error and bail
    if not encodedMessage:
        print('error: encodedMessage was received as None')
        return None

    # decode the received text message
    message = encodedMessage.decode('utf-8')


    # encode the acknowledgement text
    encodedAckText = bytes(ACK_TEXT, 'utf-8')

    # send the encoded acknowledgement text
    sock.sendall(encodedAckText)

    return message



if __name__ == '__main__':
    main()